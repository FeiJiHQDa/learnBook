-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2017-05-27 11:31:21
-- 服务器版本： 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `long_poling`
--
CREATE DATABASE IF NOT EXISTS `long_poling` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `long_poling`;

-- --------------------------------------------------------

--
-- 表的结构 `client_device`
--

CREATE TABLE `client_device` (
  `client_id` int(11) UNSIGNED NOT NULL,
  `client_name` varchar(30) DEFAULT NULL COMMENT '设备名称',
  `created_time` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户端设备号';

--
-- 转存表中的数据 `client_device`
--

INSERT INTO `client_device` (`client_id`, `client_name`, `created_time`) VALUES
(1, '爱因斯坦', '2017-05-23 06:17:11'),
(2, '玛莎拉蒂', '2017-05-23 06:17:27'),
(3, 'NAS 计划研究所', '2017-05-23 06:18:13'),
(4, '未来人类 计划', '2017-05-23 06:18:44'),
(5, '上东济南第二阳光小学22设备', '2017-05-23 06:19:53');

-- --------------------------------------------------------

--
-- 表的结构 `heart_rate`
--

CREATE TABLE `heart_rate` (
  `rate_id` int(11) UNSIGNED NOT NULL,
  `client_id` int(11) UNSIGNED DEFAULT NULL COMMENT '设备id',
  `rate_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '心跳时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='心跳表';

-- --------------------------------------------------------

--
-- 表的结构 `interactz`
--

CREATE TABLE `interactz` (
  `interactz_id` int(11) UNSIGNED NOT NULL,
  `links_id` int(11) UNSIGNED DEFAULT NULL COMMENT 'server_links 的id',
  `send_data` varchar(255) DEFAULT '' COMMENT 'start json end 的数据',
  `types` tinyint(2) DEFAULT NULL COMMENT '0/未发送，1/client接受返回sucess',
  `send_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '更新时间',
  `send_count` tinyint(4) UNSIGNED DEFAULT '0' COMMENT '重发次数',
  `revert_data` text COMMENT 'client 返回的数据'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='server与client 交换记录';

--
-- 转存表中的数据 `interactz`
--

INSERT INTO `interactz` (`interactz_id`, `links_id`, `send_data`, `types`, `send_time`, `update_at`, `send_count`, `revert_data`) VALUES
(1, 23, 'ls', 0, '2017-05-27 03:37:09', '2017-05-27 03:37:09', 0, '{"return":"1","shell":"下载成功"}'),
(2, 31, '', 0, '2017-05-25 11:26:51', '2017-05-25 11:26:51', 0, ''),
(3, 31, 'dir', 0, '2017-05-27 06:22:14', '2017-05-25 11:34:41', 0, ''),
(4, 32, 'download https://img3.doubanio.com/view/dale-online/dale_ad/public/c32d89a83836568.jpg', 1, '2017-05-27 06:59:34', '2017-05-27 06:59:34', 0, '{"return":1,"shell":"\\u4e0b\\u8f7dc32d89a83836568.jpg\\u6210\\u529f!"}'),
(5, 32, 'upload C:/xampp/htdocs\\ty\\longlink\\download\\c32d89a83836568.jpg', 1, '2017-05-27 07:15:40', '2017-05-27 07:15:40', 0, '{"return":1,"shell":"\\u4e0a\\u4f20 C:\\/xampp\\/htdocs\\\\ty\\\\longlink\\\\download\\\\c32d89a83836568.jpg \\u5230 http:\\/\\/www.long.com\\/server\\/upload.php\\u5931\\u8d25!"}'),
(6, 32, 'dir', 1, '2017-05-27 06:34:38', '2017-05-27 06:34:38', 0, '{"return":1,"shell":[" \\u9a71\\u52a8\\u5668 C \\u4e2d\\u7684\\u5377\\u6ca1\\u6709\\u6807\\u7b7e\\u3002"," \\u5377\\u7684\\u5e8f\\u5217\\u53f7\\u662f 0AEF-A749",""," C:\\\\xampp\\\\htdocs\\\\ty\\\\longlink\\\\client \\u7684\\u76ee\\u5f55","","2017\\/05\\/27  14:33    <DIR>          .","2017\\/05\\/27  14:33    <DIR>          ..","2017\\/05\\/27  14:33             5,103 client.php","2017\\/05\\/25  14:21               446 heart.php","               2 \\u4e2a\\u6587\\u4ef6          5,549 \\u5b57\\u8282","               2 \\u4e2a\\u76ee\\u5f55 146,405,584,896 \\u53ef\\u7528\\u5b57\\u8282"]}');

-- --------------------------------------------------------

--
-- 表的结构 `server_links`
--

CREATE TABLE `server_links` (
  `links_id` int(11) UNSIGNED NOT NULL COMMENT 'id',
  `client_id` int(11) UNSIGNED DEFAULT NULL COMMENT '客户端 id',
  `_stauts` tinyint(2) DEFAULT '0' COMMENT '0没链接，1链接成功',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '链接成功时间',
  `sponsor` varchar(30) DEFAULT '' COMMENT '发起人'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='server生成任务client请求链接';

--
-- 转存表中的数据 `server_links`
--

INSERT INTO `server_links` (`links_id`, `client_id`, `_stauts`, `created_at`, `updated_at`, `sponsor`) VALUES
(1, 1, 0, '2017-05-25 02:10:41', '2017-05-25 02:10:41', '测试员'),
(2, 1, 0, '2017-05-25 02:11:17', '2017-05-25 02:11:17', '测试员'),
(3, 1, 0, '2017-05-25 02:11:24', '2017-05-25 02:11:24', '测试员'),
(4, 1, 0, '2017-05-25 02:11:36', '2017-05-25 02:11:36', '测试员'),
(5, 1, 0, '2017-05-25 02:11:52', '2017-05-25 02:11:52', '测试员'),
(6, 3, 0, '2017-05-25 02:23:06', '2017-05-25 02:23:06', '测试员'),
(7, 3, 0, '2017-05-25 02:23:37', '2017-05-25 02:23:37', '测试员'),
(8, 1, 0, '2017-05-25 02:51:49', '2017-05-25 02:51:49', '测试员'),
(9, 1, 0, '2017-05-25 05:48:59', '2017-05-25 05:48:59', '测试员'),
(10, 1, 0, '2017-05-25 06:26:41', '2017-05-25 06:26:41', '测试员'),
(11, 1, 0, '2017-05-25 07:40:17', '2017-05-25 07:40:17', '测试员'),
(12, 0, 0, '2017-05-25 07:40:35', '2017-05-25 07:40:35', '测试员'),
(13, 1, 0, '2017-05-25 07:43:10', '2017-05-25 07:43:10', '测试员'),
(14, 1, 0, '2017-05-25 07:43:32', '2017-05-25 07:43:32', '测试员'),
(15, 1, 0, '2017-05-25 07:44:17', '2017-05-25 07:44:17', '测试员'),
(16, 0, 0, '2017-05-25 07:45:15', '2017-05-25 07:45:15', '测试员'),
(17, 1, 0, '2017-05-25 07:46:35', '2017-05-25 07:46:35', '测试员'),
(18, 1, 0, '2017-05-25 07:50:59', '2017-05-25 07:50:59', '测试员'),
(19, 1, 0, '2017-05-25 07:59:42', '2017-05-25 07:59:42', '测试员'),
(20, 1, 0, '2017-05-25 08:37:16', '2017-05-25 08:37:16', '测试员'),
(21, 1, 0, '2017-05-25 08:38:02', '2017-05-25 08:38:02', '测试员'),
(22, 1, 0, '2017-05-25 08:40:17', '2017-05-25 08:40:17', '测试员'),
(23, 1, 0, '2017-05-25 08:43:43', '2017-05-25 08:43:43', '测试员'),
(24, 1, 0, '2017-05-25 08:44:02', '2017-05-25 08:44:02', '测试员'),
(25, 2, 0, '2017-05-25 11:03:38', '2017-05-25 11:03:38', '测试员'),
(26, 1, 0, '2017-05-25 11:07:19', '2017-05-25 11:07:19', '测试员'),
(27, 1, 0, '2017-05-25 11:08:48', '2017-05-25 11:08:48', '测试员'),
(28, 0, 0, '2017-05-25 11:08:53', '2017-05-25 11:08:53', '测试员'),
(29, 0, 0, '2017-05-25 11:09:12', '2017-05-25 11:09:12', '测试员'),
(30, 0, 0, '2017-05-25 11:10:31', '2017-05-25 11:10:31', '测试员'),
(31, 1, 0, '2017-05-25 11:26:49', '2017-05-25 11:26:49', '测试员'),
(32, 1, 0, '2017-05-25 11:47:31', '2017-05-25 11:47:31', '测试员');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `client_device`
--
ALTER TABLE `client_device`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `heart_rate`
--
ALTER TABLE `heart_rate`
  ADD PRIMARY KEY (`rate_id`),
  ADD KEY `heart_rate_client_id_index` (`client_id`);

--
-- Indexes for table `interactz`
--
ALTER TABLE `interactz`
  ADD PRIMARY KEY (`interactz_id`),
  ADD KEY `interactz_links_id_index` (`links_id`);

--
-- Indexes for table `server_links`
--
ALTER TABLE `server_links`
  ADD PRIMARY KEY (`links_id`),
  ADD KEY `server_links_client_id_index` (`client_id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `client_device`
--
ALTER TABLE `client_device`
  MODIFY `client_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- 使用表AUTO_INCREMENT `heart_rate`
--
ALTER TABLE `heart_rate`
  MODIFY `rate_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- 使用表AUTO_INCREMENT `interactz`
--
ALTER TABLE `interactz`
  MODIFY `interactz_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- 使用表AUTO_INCREMENT `server_links`
--
ALTER TABLE `server_links`
  MODIFY `links_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id', AUTO_INCREMENT=33;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
