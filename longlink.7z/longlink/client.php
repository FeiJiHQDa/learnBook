<?php
/**
 * Created by PhpStorm.
 * User: HJKLI
 * Date: 2017/5/20
 * Time: 14:46
 */


//$http = file_get_contents('ser')
set_time_limit(0);
$handle   = fopen("http://www.long.com/service.php", "rb");
$contents = '';
while (!feof($handle)) {
    $contents = fread($handle, 8192);

    echo $contents;
    ob_flush();
    flush(); //刷新并输出PHP缓冲数据

}




fclose($handle);