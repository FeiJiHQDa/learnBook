<?php
/**
 * Created by PhpStorm.
 * User: HJKLI
 * Date: 2017/5/25
 * Time: 10:40
 */

include_once '../include/vendor.php';
include_once 'client.php';

$request = new curl();
$result  = $request->get('http://long.com/server/heart.php?client_id=3');

$result = json_decode($result['body'], true);

print_r($result);

if ($result['return']) {
    if (!empty($result['links'])) {
        new Client($result['links']);
    }
}