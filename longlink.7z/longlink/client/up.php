<?php
/**
 * Created by PhpStorm.
 * User: HJKLI
 * Date: 2017/5/27
 * Time: 15:17
 */

include_once '../include/vendor.php';
//$url = 'http://www.long.com/server/upload.php';
//
//$curl = new curl();
//
//$post = [
//    'file' => "@C:/xampp/htdocs/ty/longlink/download/c32d89a83836568.jpg",
//];
//
//ppt($post);
//$result = $curl->post($url, ['body' => $post]);

//ppt($result);
header('Content-type:text/html; charset=utf-8');//声明编码  
//模拟POST上传图片和数据  
//第一种方法：CURL  
$ch       = curl_init();
$url     = 'http://www.long.com/server/upload.php';
$curlPost = ['sid' => 1, 'file' => '@C:\xampp\htdocs\ty\longlink\download\c32d89a83836568.jpg'];
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);//POST提交  
curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
$data = curl_exec($ch);
if(curl_errno($ch)){//出错则显示错误信息
    print curl_error($ch);
}

//print_r($ch);
curl_close($ch);
echo '<pre>';
var_dump($data);


//$params = array(
//    'http' => array
//    (
//        'method' => 'POST',
//        'header'=>"Content-Type: multipart/form-data\r\n",
//    )
//);
//
//$gets = file_get_contents('C:/xampp/htdocs/ty/longlink/download/c32d89a83836568.jpg');
//
//$sx = file_put_contents('http://www.long.com/server/upload.php', $gets, 0, stream_context_create($params));

//ppt($sx);

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>


<form enctype="multipart/form-data" action="http://www.long.com/server/upload.php" method="POST">
    <!-- MAX_FILE_SIZE must precede the file input field -->
    <input type="hidden" name="MAX_FILE_SIZE" value="30000" />
    <!-- Name of input element determines name in $_FILES array -->
    Send this file: <input name="userfile" type="file" />
    <input type="submit" value="Send File" />
</form>

</body>
</html>