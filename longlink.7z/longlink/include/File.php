<?php
/**
 * Created by PhpStorm.
 * User: whaichao
 * Date: 2017/3/13
 * Time: 14:00
 */

/*
 * file类，读取配置 或者 文件的最新日期
 */

class File {

    public function __construct() {
    }

    /**
     * 获得文件内容
     * @param string $path 路径
     * @return string
     */
    public static function get($path) {
        if (file_exists($path)) {
            return file_get_contents($path);
        }
        return false;
    }



    /**
     * 读取 目录下的文件，放回 文件名称、不包括子目录
     * @param string $path 路径
     * @return array
     */
    public static function DirFileName($path) {

        $fileArr = [];
        $d = dir($path);

        while (false !== ($entry = $d->read())) {
            if ($entry == "." || $entry == "..")
                continue;
            $fileArr[] = $entry;
        }
        $d->close();
        return $fileArr;
    }

    /*
     * 读取 目录下的文件，返回 路径+文件名称，不包括子目录
     */
    public static function preg_ls ($path=".", $rec=false, $pat="/.*/") {
        // it's going to be used repeatedly, ensure we compile it for speed.
        $pat=preg_replace("|(/.*/[^S]*)|s", "\\1S", $pat);
        //Remove trailing slashes from path
        while (substr($path,-1,1)=="/") $path=substr($path,0,-1);
        //also, make sure that $path is a directory and repair any screwups
        if (!is_dir($path)) $path=dirname($path);
        //assert either truth or falsehoold of $rec, allow no scalars to mean truth
        if ($rec!==true) $rec=false;
        //get a directory handle
        $d=dir($path);
        //initialise the output array
        $ret=Array();
        //loop, reading until there's no more to read
        while (false!==($e=$d->read())) {
            //Ignore parent- and self-links
            if (($e==".")||($e=="..")) continue;
            //If we're working recursively and it's a directory, grab and merge
            if ($rec && is_dir($path."/".$e)) {
                $ret=array_merge($ret,self::preg_ls($path."/".$e,$rec,$pat));
                continue;
            }
            //If it don't match, exclude it
            if (!preg_match($pat,$e)) continue;
            //In all other cases, add it to the output array
            $ret[]=$path."/".$e;
        }
        //finally, return the array
        return $ret;
    }

    /*
     * 对文件写入数据，没有文件创建文件在写入数据
     */
    public static function put($path, $content='') {
        if ($f = file_put_contents($path, $content,  LOCK_EX)) {
            return true;
        }
        return false;
    }

    /*
     * 对文件写入数据，没有文件创建文件在写入数据, 对文本追加数据
     */
    public static function putAppend($path, $content='') {
        if ($f = file_put_contents($path, $content,  FILE_APPEND | LOCK_EX)) {
            return true;
        }
        return false;
    }

    /**
     * 删除文件
     * @param string $path 路径
     *
     */
    public static function delete($path) {
        if (file_exists($path)) {
            if (unlink($path)) {
                return true;
            }
        }
        return false;
    }

    /*
     * 获取 文件修改时间
     */
    public static function filemtime($path) {
        if (file_exists($path)) {
            return filemtime($path);
        }
        return false;
    }

    /*
     * 查看 是否有该文件
     */
    public static function fileExists($path) {
        if (file_exists($path)) {
            return true;
        }
        return false;
    }

}