<?php
/**
 * Created by PhpStorm.
 * User: whaichao
 * Date: 2017/3/10
 * Time: 9:09
 */


/**
 *  get 数据
 * @param string $url 链接
 * @param bool $type true -> 解析 josn , false -> 不做解析 array
 * @return array
 */
function http_get ($url, $type=true) {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);

    $result = curl_exec($ch);
    curl_close($ch);

    return $type ? json_decode($result, true) : $result;
}


/**
 * 发送数据
 * @param string $url 链接
 * @param string $data 参数或数组
 * @param bool $type true -> 解析 josn , false -> 不做解析 array
 * @return array
 */

function http_post ($url, $data='', $type=true) {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);

    if (!empty($data)) {
        curl_setopt($ch, CURLOPT_POST, 1);
        if (is_array($data))
            $data = http_build_query($data);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }

    $result = curl_exec($ch);
    curl_close($ch);

    return $type ? json_decode($result, true) : $result;
}


/**
 * php 异步请求
 *@param string $url URL
 * @param string|array $data POST的数据, 为 '' 是 Get,
 *@return int
 */
function sync_curl($url, $data='') {
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch,CURLOPT_TIMEOUT,1);

    if (!empty($data)) {
        curl_setopt($ch, CURLOPT_POST, 1);
        if (is_array($data))
            $data = http_build_query($data);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }

    $result = curl_exec($ch);
    curl_close($ch);

    return $result ? 1 : 0;
}

/**
 *  php 远程请求（不获取内容）函数
 * @param string $url ULR
 * @return array
 */
function sync_sock($url) {
    $host = parse_url($url,PHP_URL_HOST);
    $port = parse_url($url,PHP_URL_PORT);
    $port = $port ? $port : 80;
    $scheme = parse_url($url,PHP_URL_SCHEME);
    $path = parse_url($url,PHP_URL_PATH);
    $query = parse_url($url,PHP_URL_QUERY);
    if($query) $path .= '?'.$query;
    if($scheme == 'https') {
        $host = 'ssl://'.$host;
    }

    $fp = fsockopen($host,$port,$error_code,$error_msg,1);
    if(!$fp) {
        return array('error_code' => $error_code,'error_msg' => $error_msg);
    }
    else {
        stream_set_blocking($fp, true);//开启了手册上说的非阻塞模式
        stream_set_timeout($fp, 1);//设置超时
        $header = "GET $path HTTP/1.1\r\n";
        $header .= "Host: $host\r\n";
        $header .= "Connection: close\r\n\r\n";//长连接关闭
        fwrite($fp, $header);
        usleep(1000); // 这一句也是关键，如果没有这延时，可能在nginx服务器上就无法执行成功
        fclose($fp);
        return ['error_code' => 0, 'error_msg'=> 'no error-msg'];
    }
}

/*
 * 格式打印数据
 */
function ppt($data) {
    echo "<pre>";
    print_r($data);
    echo "</pre>";
}

/*
 *  格式打印数据 , 并且结束
 */
function ddt($data) {
    echo "<pre>";
    print_r($data);
    echo "</pre>";
    exit();
}

/*
 * 重写 htmlspecialchars
 */

function htmlspecialchars_u8($v) {
    return $v == '' ? '' : htmlspecialchars($v, ENT_QUOTES, 'UTF-8' );
}

/**
 * 获得参数
 * @param array|string $post 数组和字符串
 * @param string $default 默认值
 * @return array|string
 */
function getPost($post, $default='') {
    if (is_array($post)) {
        $newArray = [];
        foreach ($post as $k => $val) {
            $newArray[$val] = htmlspecialchars_u8 (empty($_REQUEST [$val]) ? $default : $_REQUEST[$val]);
        }
        return $newArray;
    } else {
        return htmlspecialchars_u8(empty($_REQUEST[$post]) ? $default : $_REQUEST[$post]);
    }
}

/**
 * 响应 json 数据
 */
function rJson($json) {
    header('Content-type: application/json');
    return  json_encode ( $json );
}