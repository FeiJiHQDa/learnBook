<?php
/**
 * Created by PhpStorm.
 * User: whaichao
 * Date: 2017/3/27
 * Time: 11:06
 */


/*
 *  Example using MySQL
 */
include 'adodb5/adodb.inc.php';

/*
 * This is not a class below
 */
$db = newADOConnection('mysqli');
/*
 * Make a connection to a database on the local machine
 */

$db->connect('127.0.0.1', 'root', '' , 'long_poling');
$ADODB_FETCH_MODE = ADODB_FETCH_ASSOC;
$db->setCharset('utf8');