<?php
/**
 * Created by PhpStorm.
 * User: whaichao
 * Date: 2017/3/27
 * Time: 11:32
 * 负责链接 全部的方法 类
 */

header("Content-Type:text/html; charset=utf-8");
// 设置时区
date_default_timezone_set('PRC');

require_once 'db.php';
require_once 'Tool.php';
require_once 'File.php';
require_once 'curl.php';


define('URL', 'http://www.long.com/');

define('urlServer', 'http://www.long.com/server/');
define('rootDir', dirname(dirname(__FILE__)));
