<?php
/**
 * Created by PhpStorm.
 * User: HJKLI
 * Date: 2017/5/25
 * Time: 18:00
 * * 发送 会话内容到数据库
 */

include_once '../include/vendor.php';

$links = getPost(['links_id', 'shell']);

$json = [];

try {

    if (empty($links['links_id']) || empty(strlen($links['shell']))) {
        throw new Exception('参数不完整!');
    }


    $record = [
        'links_id'    => $links['links_id'],
        'send_data'   => trim($links['shell']),
        'types'       => 0,
        'send_time'   => date('Y-m-d H:i:s'),
        'update_at'   => date('Y-m-d H:i:s'),
        'send_count'  => 0,
        'revert_data' => '',
    ];

    $db->autoExecute('interactz', $record, 'INSERT');

    $linksId = $db->insert_Id();

    if (empty($linksId)) {
        throw new Exception('网络繁忙!');
    }

    $json = [
        'return' => 1,
    ];

} catch (Exception $e) {
    $json = [
        'return'  => 0,
        'message' => $e->getMessage(),
    ];
}

echo rJson($json);