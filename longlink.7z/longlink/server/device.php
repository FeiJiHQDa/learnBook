<?php
include_once '../include/vendor.php';

// 数据库搜索
$sql     = 'SELECT * FROM client_device';
$request = $db->execute($sql);

?>

<!DOCTYPE html>
<html lang="zh-cmn-Hans">

<?php include 'head.php'?>

<body>
<div class="content-new">
    <h1>连接设备</h1>
    <div class="list-device">

        <?php foreach ($request->getAll() as $val): ?>
            <div class="list-btn">
                <button type="submit" class="btn btn-wedth btn-success" value="<?=$val['client_id']?>"><?= $val['client_name'] ?></button>
            </div>
        <?php endforeach; ?>


    </div>
</div>


<script>

    $(function () {
        $('.btn-success').on('click', function () {
//            layer.msg('只想弱弱提示');
            var val = $(this).val();

            layer.open({
                type: 2,
                area: ['800px', '650px'],
                content: 'dialogs.php?client='+val
            })

        });
    })

</script>
</body>
</html>