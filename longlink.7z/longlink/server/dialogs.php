<?php

include_once '../include/vendor.php';

$client = getPost('client');

$record = [
    'client_id' => $client,
    '_stauts' => 0,
    'created_at' => date('Y-m-d H:i:s'),
    'updated_at' => date('Y-m-d H:i:s'),
    'sponsor' => '测试员'
];


$db->autoExecute('server_links', $record, 'INSERT');

$linksId = $db->insert_Id();

//echo $linksId;
if (empty($linksId)) {
    return false;
}

?>

<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<?php include 'head.php'?>
<body>

<div class="content">
    <!--<div class="order-box">-->
    <div class="thumbnail">
        <div class="caption">

            <div class="speech-item speech-i">
                <p>pid 向设备发送 ls -l 指令 时间 ： 2017-12-2 </p>
            </div>
            <div class="speech-item speech-his">
                <p>pid 向设备发送 ls -l 指令 时间 ： 2017-12-2 </p>
            </div>
        </div>
    </div>
    <!--</div>-->
    <!--<div class="entry-box">-->
    <form onsubmit="onSubmit(); return false;">
        <p>交互窗口</p>
        <textarea name="shell" id="server-list" class="textarea thumbnail font-console"></textarea>

        <div class="say-btn">
            <input type="submit" class=" btn btn-default" value="发表" >
        </div>
    </form>
    <!--</div>-->
</div>

<script>

    function onSubmit() {
        var server = $('#server-list');
        var text = server.val();
        var links = <?=$linksId?>;
        var caption = $('.caption');
        if (!text || !links) {
            return false;
        }
        caption.append(speech_create(text));
        $.getJSON(urlServer+'createInteractz.php?links_id='+links+'&shell='+encodeURIComponent(text), function (data) {
            if (parseInt(data.return) === 1) {
//                startPoling();
            }
        })
    }


    function startPoling(links) {
        var key = 0;

        var sd = setInterval(function () {
            $.getJSON(urlServer+'getInteractz.php?links_id='+links+'&key='+encodeURIComponent(key), function (data) {
                if (parseInt(data.return) === 1) {
                    key = data.key;

                }
            })
        }, 1000);
    }

    /*
    ** 发送指令
     */
    function speech_create(text) {
        return '<div class="speech-item speech-i"> <p> 向设备发送 '+ text +' 指令 时间 ： 2017-12-2 </p> </div>';
    }

    /*
    ** 回掉指令
     */
    function speech_get(text) {
        return '<div class="speech-item speech-his"> <p>pid 向设备发送 ls -l 指令 时间 ： 2017-12-2 </p> </div>';
    }

//    http://long.com/server/
</script>

</body>
</html>