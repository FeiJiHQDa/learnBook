<?php
/**
 * Created by PhpStorm.
 * User: HJKLI
 * Date: 2017/5/25
 * Time: 18:00
 *
 * 获取 会话返回的结果
 */

include_once '../include/vendor.php';

$links = getPost(['links_id', 'key']);

$json = [];

try {
    if (empty($links['links_id']) || empty(strlen($links['key']))) {
        throw new Exception('参数不完整!');
    }

    $sql = 'SELECT `revert_data` FROM interactz WHERE links_id = ';
    $sql .= "{$links['links_id']} AND interactz_id > {$links['key']} AND types = 1";
    $dataOne = $db->getRow($sql);

    if (empty($dataOne['revert_data'])) {
        throw new Exception('网络繁忙');
    }

    $json = [
        'return' => 1,
        'message'  => $dataOne['revert_data']
    ];

} catch (Exception $e) {
    $json = [
        'return'  => 0,
        'message' => $e->getMessage(),
    ];
}

echo rJson($json);