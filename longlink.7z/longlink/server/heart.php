<?php
/**
 * Created by PhpStorm.
 * User: HJKLI
 * Date: 2017/5/25
 * Time: 10:39
 */


include_once '../include/vendor.php';

$client_id = addslashes(getPost('client_id'));

//print_r($client_id);

$dataOne = $db->getRow("SELECT `links_id` FROM server_links WHERE client_id = {$client_id}");


$json = [
    'return' => 1,
    'links' => count($dataOne) ? $dataOne['links_id'] : 0
];

echo json_encode($json);