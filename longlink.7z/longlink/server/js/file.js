/*
 * Created by HJKLI on 2017/5/25.
 *
 */

var url = 'http://long.com/';

var urlServer = url+ 'server/';


// function sleep(ms) {
//     return new Promise(resolve => setTimeout(resolve, ms));
// }