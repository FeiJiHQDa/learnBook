<?php
/**
 * Created by PhpStorm.
 * User: HJKLI
 * Date: 2017/5/27
 * Time: 10:11
 * 接收 client shell 返回的数据 (api)
 */

include_once '../include/vendor.php';

$interactz = getPost('interactz', 0);

if (empty($interactz)) {
    return rJson(['return' => 0]);
}

$record = [
    'types' => 1,
    'revert_data' => file_get_contents('php://input'),
    'update_at' => date('Y-m-d H:i:s'),
];

$where = 'interactz_id = '.$interactz;

$db->autoExecute('interactz', $record, 'UPDATE', $where);

$linksId = $db->insert_Id();
