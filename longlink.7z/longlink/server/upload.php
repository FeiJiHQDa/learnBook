<?php
/**
 * Created by PhpStorm.
 * User: HJKLI
 * Date: 2017/5/27
 * Time: 10:07
 *  接收设备 上传的文件
 */
include_once '../include/vendor.php';
if ($_POST) {
    ppt($_POST);
    var_dump($_FILES);
} else {
    exit('0000');
}