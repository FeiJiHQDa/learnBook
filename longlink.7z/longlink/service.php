<?php

set_time_limit(0);

//header( 'Content-type: text/html; charset=utf-8' );

//$url = substr(strrchr($_SERVER['REQUEST_URI'], 47), 1);

//echo $url;

for ($i = 0; $i < 3; $i++) {

//    echo json_encode(['date' => date('Y-m-d'), 'mes' => 'success']);
    echo $i .'------'.date("H:i:s")."<br />";

    ob_flush();
    flush(); //刷新并输出PHP缓冲数据
    sleep(3); //延迟3秒
}

echo json_encode(['date' => date('Y-m-d'), 'mes' => 'success']);

